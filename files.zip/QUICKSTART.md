# Audio Intelligence Platform - Quick Start Guide

## 🚀 Setup (5 minutes)

### Step 1: Prepare Files
```bash
# Create a folder for the project
mkdir audio-intelligence-platform
cd audio-intelligence-platform

# Copy all files here:
# - app.py
# - songs.py
# - requirements.txt
# - templates/index.html (create templates folder first)
# - README.md
```

### Step 2: Virtual Environment
```bash
# Create virtual environment
python -m venv venv

# Activate it
# On Mac/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the Server
```bash
python app.py
```

You should see:
```
🎵 Audio Intelligence Platform loading 250 songs...
 * Running on http://127.0.0.1:5000
```

### Step 5: Open in Browser
Visit: **http://localhost:5000**

---

## ✨ Features to Try

1. **Search:** Type "levitating" and click Search
2. **Recommend:** Select a song, adjust count, click Generate
3. **Battle:** Pick two songs in dropdowns, click Compare
4. **Analytics:** Scroll down—loaded automatically
5. **Moods:** See songs grouped by mood categories
6. **Insights:** Click a song to see AI-generated insights

---

## 📁 File Structure

```
audio-intelligence-platform/
├── app.py                    # Flask server (350 lines)
├── songs.py                  # Database + algorithms (900 lines)
├── requirements.txt          # Dependencies
├── README.md                 # Full documentation
├── templates/
│   └── index.html           # Frontend (1500+ lines)
└── venv/                     # Virtual environment
```

---

## 🔧 Customization

### Change Port
Edit `app.py`, last line:
```python
app.run(debug=True, port=8080)  # Change 5000 to 8080
```

### Add More Songs
Open `songs.py`, add to `SONGS` list:
```python
{'id': 251, 'title': 'Your Song', 'artist': 'Artist', 'energy': 0.75, 'danceability': 0.80, 'tempo': 120, 'popularity': 85},
```

### Change Colors
Open `index.html`, find CSS variables:
```css
:root {
    --primary-blue: #2563eb;  /* Change this */
    --light-blue: #3b82f6;    /* And this */
    ...
}
```

---

## 🐛 Troubleshooting

**"ModuleNotFoundError: No module named 'flask'"**
- Make sure venv is activated: `source venv/bin/activate`
- Reinstall: `pip install -r requirements.txt`

**"Address already in use"**
- Another app is using port 5000
- Kill it or change port to 8000: `app.run(port=8000)`

**Frontend shows but no data**
- Flask backend might not be running
- Check the terminal for error messages
- Make sure `songs.py` is in same directory as `app.py`

---

## 📚 Next Steps

1. Read the README.md for deep dive into algorithms
2. Open songs.py and study recommend_songs() function
3. Try tweaking the weights in the recommendation algorithm
4. Modify the mood classification logic
5. Add more songs to the dataset

---

## 🎤 Demo Script (for showing others)

1. **Search:** "Type 'levitating' and show how it finds the song"
2. **Recommend:** "Click 'Generate' and show how it finds similar songs with confidence scores"
3. **Explain:** "This uses weighted Euclidean distance to measure similarity"
4. **Battle:** "Compare two songs to see which wins by weighted scoring"
5. **Analytics:** "Show the dashboard with distributions and extremes"

---

**You're ready to go! 🎵**
