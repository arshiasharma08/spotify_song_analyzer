# 🎵 Audio Intelligence Platform

A **modern music analytics and recommendation engine** that analyzes audio features to generate intelligent recommendations, mood classification, and comparative insights. Built like a **startup AI product**, not a tutorial.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [Tech Stack](#tech-stack)
- [Installation & Setup](#installation--setup)
- [API Endpoints](#api-endpoints)
- [Recommendation Logic](#recommendation-logic)
- [Deployment](#deployment)
- [Resume Talking Points](#resume-talking-points)
- [Interview Questions You'll Get](#interview-questions-youll-get)
- [Future Roadmap](#future-roadmap)

---

## Overview

This platform demonstrates **real data engineering and machine learning concepts** through a working music analytics system. It's designed to showcase:

- **Feature engineering** (normalizing audio metrics)
- **Similarity metrics** (Euclidean distance, weighted scoring)
- **Classification systems** (mood detection via threshold logic)
- **Full-stack architecture** (Flask backend + modern frontend)
- **Professional software practices** (API design, error handling, modular code)

**Why this project stands out:**
- Uses 250 curated songs with realistic audio features
- Implements real recommendation algorithms, not magic
- Fully explained recommendation logic with comments
- Polished UI with animations and smooth interactions
- Production-grade code structure and error handling

---

## ✨ Features

### 1. **Song Search**
- Search by title or artist
- Real-time results with audio metrics displayed
- Dynamic UI updates with smooth animations

### 2. **Recommendation Engine** ⭐
- Similarity-based recommendations using **weighted Euclidean distance**
- Normalizes audio features for fair comparison
- Returns confidence scores (0-1) for each recommendation
- Weights different metrics:
  - Energy: 30%
  - Danceability: 30%
  - Tempo: 20%
  - Popularity: 20%

### 3. **Mood Classification**
Automatically classifies songs into:
- **Gym Energy** (high energy + high dance + fast tempo)
- **Party Vibes** (high energy + high dance)
- **Energetic** (high energy, lower dance)
- **Feel-Good** (medium energy + dance)
- **Study Session** (medium energy + medium dance + moderate tempo)
- **Chilled** (medium energy + medium dance + slow tempo)
- **Summer Vibes** (medium energy + dance + slow tempo)
- **Late Night** (low energy + high dance)
- **Melancholy** (low energy overall)
- **Focus Mode** (medium features, moderate tempo)

### 4. **Audio Analytics Dashboard**
- Average energy, danceability, tempo, popularity across all songs
- Highest/lowest extremes
- Distribution charts (energy levels, tempo ranges)
- Mood breakdown

### 5. **Song Battle Feature**
Compare two songs head-to-head:
- Side-by-side metric comparison
- Weighted winner calculation
- Win breakdown by category (energy, danceability, etc.)

### 6. **AI Insights**
Logic-based insights about songs:
- Energy interpretation
- Danceability analysis
- Tempo description
- Popularity context
- Mood classification
- (Not real ML, but realistic AI-style outputs)

### 7. **Educational Content**
"About" section explaining:
- How recommendation systems work
- Feature engineering and normalization
- Similarity metrics (Euclidean distance)
- Real ML applications
- How Spotify/Apple Music recommendations actually work

---

## 🏗️ Architecture

### Backend Structure

```
Audio Intelligence Platform
├── app.py                 # Flask server + API endpoints
├── songs.py              # Database + recommendation algorithms
├── requirements.txt      # Python dependencies
└── templates/
    └── index.html        # Frontend
```

### Data Flow

```
User Input (search/song)
    ↓
Flask API Endpoint
    ↓
songs.py Functions (feature extraction, similarity calc)
    ↓
JSON Response
    ↓
Frontend (render results + animate)
```

### Algorithm Flow: Recommendation Engine

```
1. User selects seed song → app.py /api/recommend
2. Extract seed song's metrics (energy, danceability, tempo, popularity)
3. Normalize metrics to 0-1 scale (crucial for fair comparison)
4. For each other song:
   a. Extract & normalize metrics
   b. Calculate weighted distance:
      distance = 0.3*(energy_diff) + 0.3*(dance_diff) 
               + 0.2*(tempo_diff) + 0.2*(pop_diff)
   c. Convert to confidence: 1 - distance
5. Sort by confidence, return top 5
6. Return recommendations with similarity scores
```

### Example: Why Normalization Matters

**Without normalization:**
- Tempo ranges 60-200 BPM (max diff: 140)
- Energy ranges 0-1 (max diff: 1)
- Tempo differences dominate the distance calculation → bad recommendations

**With normalization:**
- Normalize tempo to 0-1 scale: `(tempo - 60) / (200 - 60)`
- Now all metrics are on same scale → fair comparison

---

## 🛠️ Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Backend** | Flask (Python) | REST API, routing, business logic |
| **Frontend** | HTML5 | Semantic structure |
| **Styling** | CSS3 | Modern design with animations |
| **Interactivity** | Vanilla JavaScript | DOM manipulation, API calls, dynamic UI |
| **Data** | Python (in-memory) | 250 curated songs with audio features |
| **Algorithms** | NumPy-style math | Distance metrics, normalization |

**Why this stack:**
- Flask: lightweight, perfect for learning backend concepts
- Vanilla JS: no framework overhead, shows core web skills
- In-memory data: demonstrates data structures before databases
- Real algorithms: not hidden behind black boxes

---

## 📥 Installation & Setup

### Prerequisites
- Python 3.8+
- pip

### Steps

1. **Clone/Create the project**
```bash
mkdir audio-intelligence-platform
cd audio-intelligence-platform
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install flask
# requirements.txt is minimal—Flask is all you need!
```

4. **Run the server**
```bash
python app.py
```

5. **Open in browser**
```
http://localhost:5000
```

---

## 🔌 API Endpoints

### `POST /api/search`
Search for songs by title or artist.

**Request:**
```json
{
  "query": "levitating"
}
```

**Response:**
```json
{
  "results": [
    {
      "id": 1,
      "title": "Levitating",
      "artist": "Dua Lipa",
      "energy": 0.82,
      "danceability": 0.88,
      "tempo": 103,
      "popularity": 94
    }
  ],
  "count": 1
}
```

---

### `POST /api/recommend`
Generate recommendations based on a song.

**Request:**
```json
{
  "song_id": 1,
  "count": 5
}
```

**Response:**
```json
{
  "seed": { /* seed song object */ },
  "recommendations": [
    {
      "id": 2,
      "title": "Don't Start Now",
      "artist": "Dua Lipa",
      "similarity_score": 0.94,
      "mood": "Party Vibes",
      ...
    }
  ]
}
```

---

### `POST /api/battle`
Compare two songs.

**Request:**
```json
{
  "song1_id": 1,
  "song2_id": 2
}
```

**Response:**
```json
{
  "song1": { "score": 0.82, "metrics": {...} },
  "song2": { "score": 0.78, "metrics": {...} },
  "winner": "song1",
  "details": { "energy": "song1", "danceability": "song1", ... }
}
```

---

### `GET /api/moods`
Get all songs grouped by mood category.

**Response:**
```json
{
  "moods": {
    "Party Vibes": [...],
    "Study Session": [...],
    "Melancholy": [...]
  },
  "total_songs": 250,
  "mood_count": 10
}
```

---

### `GET /api/analytics`
Get platform-wide analytics.

**Response:**
```json
{
  "summary": {
    "total_songs": 250,
    "avg_energy": 0.63,
    "avg_danceability": 0.65,
    "avg_tempo": 105.2,
    "avg_popularity": 82.1
  },
  "extremes": {
    "most_danceable": {...},
    "highest_energy": {...}
  },
  "distributions": {
    "tempo": {"slow": 45, "moderate": 120, "fast": 85},
    "energy": {"low": 60, "medium": 120, "high": 70}
  }
}
```

---

### `POST /api/insights`
Generate AI-style insights about a song.

**Request:**
```json
{
  "song_id": 1
}
```

**Response:**
```json
{
  "song": { /* song object */ },
  "mood": "Party Vibes",
  "insights": [
    "⚡ High-energy track perfect for intense workouts...",
    "💃 Highly danceable with strong rhythmic foundation...",
    "🎼 Moderate tempo (103 BPM) balanced for versatility...",
    "..."
  ]
}
```

---

## 🧠 Recommendation Logic (Deep Dive)

### Why Euclidean Distance?

Euclidean distance measures "similarity" between points in multi-dimensional space:

```
distance = sqrt((e1-e2)² + (d1-d2)² + (t1-t2)² + (p1-p2)²)

Lower distance = more similar songs
```

**Example calculation:**

```
Seed: "Levitating" (energy: 0.82, dance: 0.88)
Candidate: "Don't Start Now" (energy: 0.80, dance: 0.84)

distance = sqrt((0.82-0.80)² + (0.88-0.84)²)
         = sqrt(0.0004 + 0.0016)
         = sqrt(0.002)
         = 0.045 (very small = very similar!)

confidence = 1 - 0.045 = 0.955 (95.5% match)
```

### Why Weighted?

Different features matter differently:
- **Energy (30%):** Most important—people want energy-matched tracks
- **Danceability (30%):** Second most—danceability defines mood
- **Tempo (20%):** Supports energy—fast songs usually energetic
- **Popularity (20%):** Context—popular songs make good recommendations

If we gave equal weight to all, obscure slow songs might match a popular upbeat track just by accident.

### Normalization Example

**Tempo without normalization:**
- Song A: 90 BPM
- Song B: 110 BPM
- Difference: 20 BPM (large number!)

**With normalization (60-200 range):**
- Song A: (90-60)/(200-60) = 30/140 = **0.214**
- Song B: (110-60)/(200-60) = 50/140 = **0.357**
- Difference: 0.357 - 0.214 = **0.143** (on 0-1 scale, comparable to energy/dance)

---

## 🚀 Deployment

### Option 1: Heroku (Free tier ended, but still an option)
```bash
git init
echo "flask==2.3.0" > requirements.txt
echo "web: python app.py" > Procfile

git add .
git commit -m "Initial commit"
heroku create your-app-name
git push heroku main
```

### Option 2: Railway.app (Recommended)
1. Push to GitHub
2. Connect GitHub to Railway
3. Set start command: `python app.py`
4. Deploy

### Option 3: PythonAnywhere (Free option)
1. Sign up at pythonanywhere.com
2. Upload files
3. Create web app, configure Flask
4. Visit your URL

### Option 4: Local (Development)
```bash
python app.py
# Visit http://localhost:5000
```

---

## 📝 Resume Talking Points

### What You Built
*"I built an audio intelligence platform—a full-stack music analytics system that generates intelligent recommendations using feature engineering and similarity metrics. 250 songs, custom mood classification, and real recommendation algorithms."*

### Key Technical Achievements

**Data & Algorithms:**
- ✅ Implemented **weighted Euclidean distance** for song recommendations
- ✅ Feature **normalization** (crucial for fair metric comparison)
- ✅ **Mood classification** system using threshold-based logic
- ✅ Designed battle algorithm with **weighted scoring**

**Backend:**
- ✅ RESTful API with **6 endpoints** (search, recommend, battle, moods, analytics, insights)
- ✅ Clean separation of concerns (business logic in `songs.py`, routing in `app.py`)
- ✅ Proper error handling and HTTP status codes
- ✅ JSON serialization and API response design

**Frontend:**
- ✅ Smooth animations and transitions
- ✅ Dynamic DOM updates without page refresh
- ✅ Responsive design with modern UI aesthetic
- ✅ Chart visualizations (CSS + JavaScript)

**Software Engineering:**
- ✅ Well-commented code explaining algorithms
- ✅ Modular functions (reusable, testable)
- ✅ Professional project structure
- ✅ Production-ready error handling

---

## 🎤 Interview Questions You'll Get

### "How does your recommendation system work?"
*Answer:* "I use weighted Euclidean distance to measure similarity between songs. I normalize all features to 0-1 scale first—crucial because tempo ranges 60-200 while energy is 0-1. Then I weight four metrics: energy (30%), danceability (30%), tempo (20%), popularity (20%). Lower distance = more similar. I return the top 5 recommendations with confidence scores."

### "Why normalize the features?"
*Answer:* "Without normalization, tempo differences would dominate because they're larger numbers. Normalizing puts everything on a 0-1 scale so all metrics are compared fairly. Example: a 20 BPM difference shouldn't matter more than a 0.2 energy difference."

### "How would you improve this with real machine learning?"
*Answer:* "Three approaches: (1) Clustering—use K-means to find natural groups of songs, then recommend from the same cluster. (2) Embeddings—train a neural network to map songs to a learned representation space. (3) Collaborative filtering—if I had user data, I'd recommend songs that similar users liked."

### "How would you scale this to millions of songs?"
*Answer:* "Currently O(n) for each recommendation. At scale: (1) Use Spotify's API instead of local data. (2) Pre-compute clusters or use KNN indexes for fast nearest-neighbor search. (3) Cache popular recommendations. (4) Implement pagination for API results."

### "Why did you choose Flask over Django/FastAPI?"
*Answer:* "Flask is lightweight and ideal for learning. It teaches you HTTP routing and REST API design without framework magic. FastAPI would be better for production (async, validation), but Flask is perfect for demonstrating core concepts."

### "What would you do differently in production?"
*Answer:* "Add a real database (PostgreSQL), implement user authentication, cache recommendations with Redis, add logging/monitoring, write unit tests, use environment variables for config, implement rate limiting, and switch to Spotify API for real data."

---

## 🗺️ Future Roadmap

### Phase 2: User Personalization
- User accounts + authentication
- Save favorite songs and recommendations
- Listening history tracking
- Personalized insights over time

### Phase 3: Machine Learning
- Train embedding model on audio features
- Implement clustering for mood groups
- Collaborative filtering (if users exist)
- A/B test different recommendation weights

### Phase 4: Real Data Integration
- Spotify API integration
- Pull real audio features
- Access to millions of songs
- User's actual listening history

### Phase 5: Advanced Features
- Playlist generation
- Genre-specific recommendations
- Time-based mood detection (morning vs. night)
- Social features (share recommendations)
- Genre analysis and classification

### Phase 6: AI Enhancement
- Fine-tuned LLM for generating descriptions
- Computer vision for album art analysis
- Speech-to-text for voice search
- Sentiment analysis on lyrics

---

## 📊 Project Stats

- **Songs:** 250 curated tracks
- **Audio Features:** 4 per song (energy, danceability, tempo, popularity)
- **Recommendation Weights:** 4 features with custom weights
- **Mood Categories:** 10 distinct moods
- **API Endpoints:** 6 fully functional endpoints
- **Lines of Code:** ~1,500 (app.py ~350, songs.py ~900, frontend ~250)

---

## 💡 Why This Project is Interview-Worthy

1. **Shows real thinking:** Not a tutorial clone—custom algorithm choices explained
2. **Polished execution:** Professional UI/UX, not "just works"
3. **Scalable architecture:** Easy to explain how you'd scale it
4. **Interview ammunition:** Dozen talking points ready to go
5. **Portfolio proof:** Demonstrates full-stack skills + data sense
6. **Real concepts:** Features, normalization, similarity metrics—all real ML stuff
7. **Clean code:** Well-structured, modular, commented

---

## 📞 Questions?

This project is designed to teach. Every function has comments explaining the "why," not just the "how."

**Key files to understand:**
- `songs.py`: `euclidean_distance()`, `recommend_songs()`, `battle_songs()`
- `app.py`: `/api/recommend`, `/api/analytics`, `/api/insights`
- `index.html`: Animations, interactive search, visualizations

---

**Built with passion. Ready for interviews. 🎵**
